package communication;

import java.net.Socket;

public interface Serveur {

	public void deconnexion(Socket sss);

}
